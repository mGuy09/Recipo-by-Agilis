import React, { useState } from 'react'
import {TfiClose, TfiMenu} from 'react-icons/tfi'
import {FaUserAlt} from 'react-icons/fa'

function Navbar() {
  const [nav, setNav] = useState(false)
  const [dropdown , setDropdown] = useState(false)

  const OpenClose = () => {
    setNav(!nav)
  }
  const DropdownOpenClose = () => {
    setDropdown(!dropdown)
  }
  return (
    <>
      <div className='flex justify-between'>
        <div className='flex m-3 mt-3 items-center'>
        <div>
          <TfiMenu size={30} className='m-1 cursor-pointer' onClick={OpenClose}/>
        </div>
        <h1 className='ml-3 font-semibold text-2xl'>RECIPO</h1>
        </div>
        <div className='m-3'>
          <FaUserAlt size={25} className='hidden lg:flex mx-5 mt-2 cursor-pointer items-center' onClick={DropdownOpenClose}/>
            <div className={!dropdown ? 'absolute hidden bg-white z-10 right-2 top-[62px]'  :'absolute flex bg-white z-10 right-2 top-[62px] duration-200'}>
              <ul className='flex flex-col duration-200'>
                <li className='border-b border-b-gray-200 py-2 px-3 hover:bg-orange-500 duration-200 cursor-pointer'>User Page</li>
                <li className='border-b border-b-gray-200 py-2 px-3 hover:bg-orange-500 duration-150 cursor-pointer'>Options</li>
                <li className='py-2 px-3 hover:bg-orange-500 duration-100 cursor-pointer'>Login</li>
              </ul>
            </div>
        </div>
      </div>

      <div className={!nav ? ' fixed left-0 top-0 bg-white w-full lg:w-[500px] border-r h-full border-r-gray-200 text-xl font-semibold translate-x-[-100%] duration-500 z-10' : 
      'fixed left-0 top-0 bg-white w-full h-full lg:w-[500px] border-r border-r-gray-200 text-xl font-semibold duration-500 ease-in-out z-10'}>
        <div>
          <div className='flex justify-between py-7 items-center'>
          <h1 className='px-4  text-3xl font-bold'>RECIPO</h1>
          <TfiClose size={20} className='mx-4 cursor-pointer' onClick={OpenClose} />
          </div>
          <ul className='border-t border-t-gray-200'>
            <li className='p-4 hover:bg-orange-500 hover:text-white'>Home</li>
            <li className='p-4 hover:bg-orange-500 hover:text-white'>Get Started</li>
            <li className='p-4 hover:bg-orange-500 hover:text-white'>About</li>
            <li className='p-4 hover:bg-orange-500 hover:text-white'>Sign In</li>
          </ul>
        </div>
      </div>
    </>
  )
}

export default Navbar