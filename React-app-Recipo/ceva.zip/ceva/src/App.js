import { Route, Routes } from "react-router";
import Footer from "./Components/Footer";
import Navbar from "./Components/Navbar";
import Home from "./Pages/Home";


function App() {
  return (
    <div>
      <Navbar />
      <Routes>
        <Route path="/" element={<Home/>}/>
        <Route path='/Login' element=''/>
        <Route path="/Register" element='' />
      </Routes>
      <Footer />
    </div>
  );
}

export default App;
