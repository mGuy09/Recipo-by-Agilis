import React from 'react'
import Getstarted from '../Components/Getstarted'
import Hero from '../Components/Hero'

function Home() {
  return (
    <>
        <Hero />
        <Getstarted />    
    </>
  )
}

export default Home